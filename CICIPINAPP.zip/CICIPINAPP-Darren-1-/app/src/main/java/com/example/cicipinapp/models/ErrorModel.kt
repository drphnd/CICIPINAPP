package com.example.cicipinapp.models

data class ErrorModel (
    val errors: String
)