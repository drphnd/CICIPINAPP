package com.example.cicipinapp.enums

enum class PagesEnum(){
    Login,
    Register,
    Home,
    AddRestaurant,
    ShowMap,
    RestaurantDetail
}