package com.example.cicipinapp.enums

enum class PrioritiesEnum() {
    High,
    Medium,
    Low
}