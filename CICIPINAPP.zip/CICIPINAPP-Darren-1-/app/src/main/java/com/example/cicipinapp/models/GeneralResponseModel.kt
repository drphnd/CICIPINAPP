package com.example.cicipinapp.models


data class GeneralResponseModel (
    val data: String
)